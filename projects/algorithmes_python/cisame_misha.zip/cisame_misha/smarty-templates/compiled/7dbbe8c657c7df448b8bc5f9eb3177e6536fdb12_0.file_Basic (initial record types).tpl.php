<?php
/* Smarty version 5.4.1, created on 2025-01-21 14:50:07
  from 'file:Basic (initial record types).tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_678fa60f9c7730_63788215',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7dbbe8c657c7df448b8bc5f9eb3177e6536fdb12' => 
    array (
      0 => 'Basic (initial record types).tpl',
      1 => 1711011435,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_678fa60f9c7730_63788215 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/HEURIST/HEURIST_FILESTORE/cisame_misha/smarty-templates';
?>
<h2>Basic report as an example</h2> 
<i><pre>
     Please use this as an example from which to create your own reports, by copying this template.<br/>
     To do this, choose <b>Edit</b> (first button above the report), then click the <b>Save As</b> button.<br/>
     You can also create a new report template with the <b>Create a new template</b> icon (second button)<br/>
     As you edit, hit the <b>Test</b> button repeatedly to see how your changes are working.<br/>
     Ctrl-Z will undo most recent change - can be repeated to backtrack through changes.<br/>
</pre></i>


<b>Total records:</b> <?php echo $_smarty_tpl->getValue('heurist')->getSysInfo('db_total_records');?>

<br><br>

<?php $_smarty_tpl->assign('rty_Counts', $_smarty_tpl->getValue('heurist')->getSysInfo('db_rty_counts'), false, NULL);?>
<table>
        <tr>
             <td><b>Entity type</b></td>
             <td>&nbsp;&nbsp;</td>
             <td><b>Count</b></td>
        </tr>
        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('rty_Counts'), 'rty_Count', false, 'rty_ID');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('rty_ID')->value => $_smarty_tpl->getVariable('rty_Count')->value) {
$foreach0DoElse = false;
?>
                     <tr>
               <td><?php echo $_smarty_tpl->getValue('heurist')->rty_Name($_smarty_tpl->getValue('rty_ID'));?>
 </td>
               <td></td>
               <td><?php echo $_smarty_tpl->getValue('rty_Count');?>
</td>
          </tr>
       <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
</table>

<hr>

<?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('results'), 'r');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('r')->value) {
$foreach1DoElse = false;
?> <?php $_smarty_tpl->assign('r', $_smarty_tpl->getValue('heurist')->getRecord($_smarty_tpl->getValue('r')), false, NULL);?>

    
  

     

     <?php if (($_smarty_tpl->getValue('r')['recTypeID'] == $_smarty_tpl->getValue('heurist')->constant("RT_MEDIA_RECORD"))) {?>
       Media: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
  
       <?php echo $_smarty_tpl->getValue('r')['f1'];?>
<br/> <br/> </b> 
       <?php echo $_smarty_tpl->getSmarty()->getFunctionHandler('wrap')->handle(array('var'=>$_smarty_tpl->getValue('r')['f38_originalvalue'],'dt'=>"file",'width'=>"300",'height'=>"auto"), $_smarty_tpl);?>
<br/>

       <?php if (($_smarty_tpl->getValue('r')['f3'])) {?>          <?php echo $_smarty_tpl->getValue('r')['f3'];?>
<br/>
       <?php }?>

     <?php } else { ?>


     

     <?php if (($_smarty_tpl->getValue('r')['recTypeID'] == $_smarty_tpl->getValue('heurist')->constant("RT_ORGANISATION"))) {?>
       Organisation: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
 
       <?php echo $_smarty_tpl->getValue('r')['f1'];?>
 </b>

       <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('r')['f22s'], 'f22');
$foreach2DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('f22')->value) {
$foreach2DoElse = false;
?>         <?php echo $_smarty_tpl->getValue('f22')['term'];?>

       <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
       <?php if (($_smarty_tpl->getValue('r')['f2'])) {?>
         <?php echo $_smarty_tpl->getValue('r')['f2'];?>
       <?php }?>
       <?php echo $_smarty_tpl->getSmarty()->getFunctionHandler('wrap')->handle(array('var'=>$_smarty_tpl->getValue('r')['recURL'],'dt'=>"url"), $_smarty_tpl);?>
<br/>

       <?php if (($_smarty_tpl->getValue('r')['f3'])) {?>
         <br/><?php echo $_smarty_tpl->getValue('r')['f3'];?>
       <?php }?>


       <?php if (($_smarty_tpl->getValue('r')['f39'])) {?>
         <br/>
       	 <?php echo $_smarty_tpl->getSmarty()->getFunctionHandler('wrap')->handle(array('var'=>$_smarty_tpl->getValue('r')['f39_originalvalue'],'dt'=>"file",'width'=>"150",'height'=>"auto"), $_smarty_tpl);?>
<br/>        <?php }?>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->getValue('r')['recTypeID'] == $_smarty_tpl->getValue('heurist')->constant("RT_PERSON"))) {?>
       Person: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
  
       <?php echo $_smarty_tpl->getValue('r')['f18'];?>
       <?php echo $_smarty_tpl->getValue('r')['f1'];?>
       </b>

       <?php echo $_smarty_tpl->getValue('r')['f10'];?>

       <?php if (($_smarty_tpl->getValue('r')['f11'])) {?>
          - <?php echo $_smarty_tpl->getValue('r')['f11'];?>
.        <?php }?>

       <?php if (($_smarty_tpl->getValue('r')['f26'])) {?>
       		Birth country: <?php echo $_smarty_tpl->getValue('r')['f26']['term'];?>
       <?php }?>

       <?php if (($_smarty_tpl->getValue('r')['f3'])) {?>
         <br/><br/><?php echo $_smarty_tpl->getValue('r')['f3'];?>
       <?php }?>

			 <br/><br/>

       <?php echo $_smarty_tpl->getSmarty()->getFunctionHandler('wrap')->handle(array('var'=>$_smarty_tpl->getValue('r')['f39_originalvalue'],'dt'=>"file",'width'=>"300",'height'=>"auto"), $_smarty_tpl);?>
<br/> 
       <?php if (($_smarty_tpl->getValue('r')['f28'])) {?>          <br/>Birth place map below:<br/><?php echo $_smarty_tpl->getSmarty()->getFunctionHandler('wrap')->handle(array('var'=>$_smarty_tpl->getValue('r')['f28_originalvalue'],'dt'=>"geo"), $_smarty_tpl);?>
        <?php }?>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->getValue('r')['recTypeID'] == "11")) {?>
     Author: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
  
     <i>
     <?php echo $_smarty_tpl->getValue('r')['f1'];?>
,      <?php echo $_smarty_tpl->getValue('r')['f18'];?>
     </i>
     </b> <br/>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->getValue('r')['recTypeID'] == $_smarty_tpl->getValue('heurist')->constant("RT_INTERNET_BOOKMARK"))) {?>
       URL: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
  
       <?php echo $_smarty_tpl->getValue('r')['f1'];?>
 </b>

       <br/><br/><?php echo $_smarty_tpl->getSmarty()->getFunctionHandler('wrap')->handle(array('var'=>$_smarty_tpl->getValue('r')['recURL'],'dt'=>"url"), $_smarty_tpl);?>


       <?php if (($_smarty_tpl->getValue('r')['f3'])) {?>
         <br/><br/><?php echo $_smarty_tpl->getValue('r')['f3'];?>
       <?php }?>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->getValue('r')['recTypeID'] == $_smarty_tpl->getValue('heurist')->constant("RT_PLACE"))) {?>
       Place: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
  
       <?php echo $_smarty_tpl->getValue('r')['f1'];?>
       [<?php echo $_smarty_tpl->getValue('r')['f133']['term'];?>
]       <?php echo $_smarty_tpl->getValue('r')['f26']['term'];?>
       </b><br/>

       <br/><?php echo $_smarty_tpl->getSmarty()->getFunctionHandler('wrap')->handle(array('var'=>$_smarty_tpl->getValue('r')['f28_originalvalue'],'dt'=>"geo"), $_smarty_tpl);?>
 
     <?php } else { ?>

     

     <?php if (($_smarty_tpl->getValue('r')['recTypeID'] == $_smarty_tpl->getValue('heurist')->constant("RT_NOTE"))) {?>
       Note: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
</b>  
       <b><?php echo $_smarty_tpl->getValue('r')['f1'];?>
</b><br/> 
       <br/><?php echo $_smarty_tpl->getValue('r')['f3'];?>

     <?php } else { ?>

     

       Other: <b><?php echo $_smarty_tpl->getValue('r')['recID'];?>
</b>  
       <b><?php echo $_smarty_tpl->getValue('r')['f1'];?>
</b><br/> 
			 <br/> Unsupported record type: please edit the template to add support for it
 
     
               
  
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
      
      

<br/> <hr> <br/> 

<?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?> 

<h2>End of report</h2> <?php }
}
