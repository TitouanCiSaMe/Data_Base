<?php
/* Smarty version 3.1.48, created on 2024-03-21 08:57:15
  from '/var/www/html/HEURIST/HEURIST_FILESTORE/cisame_misha/smarty-templates/Basic (initial record types).tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_65fbf66bdfc5c7_35729415',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6ab8516c8540378f1545be6ecc8a596645bd455e' => 
    array (
      0 => '/var/www/html/HEURIST/HEURIST_FILESTORE/cisame_misha/smarty-templates/Basic (initial record types).tpl',
      1 => 1711011435,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65fbf66bdfc5c7_35729415 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h2>Basic report as an example</h2> 
<i><pre>
     Please use this as an example from which to create your own reports, by copying this template.<br/>
     To do this, choose <b>Edit</b> (first button above the report), then click the <b>Save As</b> button.<br/>
     You can also create a new report template with the <b>Create a new template</b> icon (second button)<br/>
     As you edit, hit the <b>Test</b> button repeatedly to see how your changes are working.<br/>
     Ctrl-Z will undo most recent change - can be repeated to backtrack through changes.<br/>
</pre></i>


<b>Total records:</b> <?php echo $_smarty_tpl->tpl_vars['heurist']->value->getSysInfo('db_total_records');?>

<br><br>

<?php $_smarty_tpl->_assignInScope('rty_Counts', $_smarty_tpl->tpl_vars['heurist']->value->getSysInfo('db_rty_counts'));?>
<table>
        <tr>
             <td><b>Entity type</b></td>
             <td>&nbsp;&nbsp;</td>
             <td><b>Count</b></td>
        </tr>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['rty_Counts']->value, 'rty_Count', false, 'rty_ID');
$_smarty_tpl->tpl_vars['rty_Count']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['rty_ID']->value => $_smarty_tpl->tpl_vars['rty_Count']->value) 
{ if(smarty_function_progress(array(), $_smarty_tpl)){ return; }

$_smarty_tpl->tpl_vars['rty_Count']->do_else = false;
?>
                     <tr>
               <td><?php echo $_smarty_tpl->tpl_vars['heurist']->value->rty_Name($_smarty_tpl->tpl_vars['rty_ID']->value);?>
 </td>
               <td></td>
               <td><?php echo $_smarty_tpl->tpl_vars['rty_Count']->value;?>
</td>
          </tr>
       <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</table>

<hr>

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['results']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?> <?php $_smarty_tpl->_assignInScope('r', $_smarty_tpl->tpl_vars['heurist']->value->getRecord($_smarty_tpl->tpl_vars['r']->value));?>

    
  

     

     <?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeID'] == $_smarty_tpl->tpl_vars['heurist']->value->constant("RT_MEDIA_RECORD"))) {?>
       Media: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
       <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
<br/> <br/> </b> 
       <?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['f38_originalvalue'],'dt'=>"file",'width'=>"300",'height'=>"auto"),$_smarty_tpl);?>
<br/>

       <?php if (($_smarty_tpl->tpl_vars['r']->value['f3'])) {?>          <?php echo $_smarty_tpl->tpl_vars['r']->value['f3'];?>
<br/>
       <?php }?>

     <?php } else { ?>


     

     <?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeID'] == $_smarty_tpl->tpl_vars['heurist']->value->constant("RT_ORGANISATION"))) {?>
       Organisation: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
 
       <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
 </b>

       <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['r']->value['f22s'], 'f22');
$_smarty_tpl->tpl_vars['f22']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['f22']->value) {
$_smarty_tpl->tpl_vars['f22']->do_else = false;
?>         <?php echo $_smarty_tpl->tpl_vars['f22']->value['term'];?>

       <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
       <?php if (($_smarty_tpl->tpl_vars['r']->value['f2'])) {?>
         <?php echo $_smarty_tpl->tpl_vars['r']->value['f2'];?>
       <?php }?>
       <?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['recURL'],'dt'=>"url"),$_smarty_tpl);?>
<br/>

       <?php if (($_smarty_tpl->tpl_vars['r']->value['f3'])) {?>
         <br/><?php echo $_smarty_tpl->tpl_vars['r']->value['f3'];?>
       <?php }?>


       <?php if (($_smarty_tpl->tpl_vars['r']->value['f39'])) {?>
         <br/>
       	 <?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['f39_originalvalue'],'dt'=>"file",'width'=>"150",'height'=>"auto"),$_smarty_tpl);?>
<br/>        <?php }?>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeID'] == $_smarty_tpl->tpl_vars['heurist']->value->constant("RT_PERSON"))) {?>
       Person: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
       <?php echo $_smarty_tpl->tpl_vars['r']->value['f18'];?>
       <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
       </b>

       <?php echo $_smarty_tpl->tpl_vars['r']->value['f10'];?>

       <?php if (($_smarty_tpl->tpl_vars['r']->value['f11'])) {?>
          - <?php echo $_smarty_tpl->tpl_vars['r']->value['f11'];?>
.        <?php }?>

       <?php if (($_smarty_tpl->tpl_vars['r']->value['f26'])) {?>
       		Birth country: <?php echo $_smarty_tpl->tpl_vars['r']->value['f26']['term'];?>
       <?php }?>

       <?php if (($_smarty_tpl->tpl_vars['r']->value['f3'])) {?>
         <br/><br/><?php echo $_smarty_tpl->tpl_vars['r']->value['f3'];?>
       <?php }?>

			 <br/><br/>

       <?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['f39_originalvalue'],'dt'=>"file",'width'=>"300",'height'=>"auto"),$_smarty_tpl);?>
<br/> 
       <?php if (($_smarty_tpl->tpl_vars['r']->value['f28'])) {?>          <br/>Birth place map below:<br/><?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['f28_originalvalue'],'dt'=>"geo"),$_smarty_tpl);?>
        <?php }?>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeID'] == "11")) {?>
     Author: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
     <i>
     <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
,      <?php echo $_smarty_tpl->tpl_vars['r']->value['f18'];?>
     </i>
     </b> <br/>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeID'] == $_smarty_tpl->tpl_vars['heurist']->value->constant("RT_INTERNET_BOOKMARK"))) {?>
       URL: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
       <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
 </b>

       <br/><br/><?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['recURL'],'dt'=>"url"),$_smarty_tpl);?>


       <?php if (($_smarty_tpl->tpl_vars['r']->value['f3'])) {?>
         <br/><br/><?php echo $_smarty_tpl->tpl_vars['r']->value['f3'];?>
       <?php }?>

     <?php } else { ?>

     

     <?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeID'] == $_smarty_tpl->tpl_vars['heurist']->value->constant("RT_PLACE"))) {?>
       Place: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
  
       <?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
       [<?php echo $_smarty_tpl->tpl_vars['r']->value['f133']['term'];?>
]       <?php echo $_smarty_tpl->tpl_vars['r']->value['f26']['term'];?>
       </b><br/>

       <br/><?php echo smarty_function_wrap(array('var'=>$_smarty_tpl->tpl_vars['r']->value['f28_originalvalue'],'dt'=>"geo"),$_smarty_tpl);?>
 
     <?php } else { ?>

     

     <?php if (($_smarty_tpl->tpl_vars['r']->value['recTypeID'] == $_smarty_tpl->tpl_vars['heurist']->value->constant("RT_NOTE"))) {?>
       Note: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
</b>  
       <b><?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
</b><br/> 
       <br/><?php echo $_smarty_tpl->tpl_vars['r']->value['f3'];?>

     <?php } else { ?>

     

       Other: <b><?php echo $_smarty_tpl->tpl_vars['r']->value['recID'];?>
</b>  
       <b><?php echo $_smarty_tpl->tpl_vars['r']->value['f1'];?>
</b><br/> 
			 <br/> Unsupported record type: please edit the template to add support for it
 
     
               
  
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
  <?php }?>	
      
      

<br/> <hr> <br/> 

<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> 

<h2>End of report</h2> <?php }
}
